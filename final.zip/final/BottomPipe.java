import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;

public class BottomPipe
{
	private Image bPipeImage;
	private int x_Location;
	private int y_Location;
	
	public BottomPipe(int initialWidth, int initialHeight) 
	{
		ImageIcon PipeImage = new ImageIcon("resources/tube_bottom.png");
		Image bPipeImage = PipeImage.getImage();
		scaleImage(initialWidth, initialHeight);
	}
	
	public void scaleImage(int width, int height) 
	{
		bPipeImage = bPipeImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);	
	}
	
	public Image getBottomPipe() 
	{
		return bPipeImage;
	}
	
	public int getY() 
	{
		return y_Location;
	}
	
	public int getX() 
	{
		return x_Location;
	}
	
	public int getHeight()
	{
		return bPipeImage.getHeight(null);
	}
	
	public int getWidth() 
	{
		return bPipeImage.getWidth(null);
	}
	
	public Rectangle getRectangle() 
	{
		Rectangle birdBox = new Rectangle(x_Location, y_Location, bPipeImage.getWidth(null), bPipeImage.getHeight(null));
		return (birdBox);
	}
	
	public BufferedImage getBI() 
	{
		BufferedImage bi = new BufferedImage(bPipeImage.getWidth(null), bPipeImage.getHeight(null), BufferedImage.TYPE_INT_ARGB);
		Graphics g = bi.getGraphics();
		g.drawImage(bPipeImage, 0, 0, null);
		g.dispose();
		return bi;
	}
	
	public void setX(int x) 
	{
		x_Location = x;
	}
	
	public void setY(int y) 
	{
		y_Location = y;
	}
}