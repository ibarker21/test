import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;

public class TopPipe
{
	private Image tPipeImage;
	private int x_Location;
	private int y_Location;
	
	public TopPipe(int initialWidth, int initialHeight) 
	{
		ImageIcon pipeImage = new ImageIcon("resources/tube_top.png");
		Image tPipeImage = pipeImage.getImage();
		scaleImage(initialWidth, initialHeight);
	}
	
	public void scaleImage(int width, int height) 
	{
		tPipeImage = tPipeImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);	
	}
	
	public Image getTopPipe() 
	{
		return tPipeImage;
	}
	
	public int getY() 
	{
		return y_Location;
	}
	
	public int getX() 
	{
		return x_Location;
	}
	
	public int getHeight()
	{
		return tPipeImage.getHeight(null);
	}
	
	public int getWidth() 
	{
		return tPipeImage.getWidth(null);
	}
	
	public Rectangle getRectangle() 
	{
		Rectangle birdBox = new Rectangle(x_Location, y_Location, tPipeImage.getWidth(null), tPipeImage.getHeight(null));
		return (birdBox);
	}
	
	public BufferedImage getBI() 
	{
		BufferedImage bi = new BufferedImage(tPipeImage.getWidth(null), tPipeImage.getHeight(null), BufferedImage.TYPE_INT_ARGB);
		Graphics g = bi.getGraphics();
		g.drawImage(tPipeImage, 0, 0, null);
		g.dispose();
		return bi;
	}
	
	public void setX(int x) 
	{
		x_Location = x;
	}
	
	public void setY(int y) 
	{
		y_Location = y;
	}
}