import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;

public class Bird 
{
	private Image birdImage;
	private int x_Location;
	private int y_Location;
	
	public Bird(int initialWidth, int initialHeight) 
	{
		ImageIcon imageBird = new ImageIcon("resources/blue_bird.png");
		Image birdImage = imageBird.getImage();
		scaleImage(initialWidth, initialHeight);
	}
	
	public void scaleImage(int width, int height) 
	{
		birdImage = birdImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);	
	}
	
	public Image getBird() 
	{
		return birdImage;
	}
	
	public int getY() 
	{
		return y_Location;
	}
	
	public int getX() 
	{
		return x_Location;
	}
	
	public int getHeight()
	{
		return birdImage.getHeight(null);
	}
	
	public int getWidth() 
	{
		return birdImage.getWidth(null);
	}
	
	public Rectangle getRectangle() 
	{
		Rectangle birdBox = new Rectangle(x_Location, y_Location, birdImage.getWidth(null), birdImage.getHeight(null));
		return (birdBox);
	}
	
	public BufferedImage getBI() 
	{
		BufferedImage bi = new BufferedImage(birdImage.getWidth(null), birdImage.getHeight(null), BufferedImage.TYPE_INT_ARGB);
		Graphics g = bi.getGraphics();
		g.drawImage(birdImage, 0, 0, null);
		g.dispose();
		return bi;
	}
	
	public void setX(int x) 
	{
		x_Location = x;
	}
	
	public void setY(int y) 
	{
		y_Location = y;
	}
}
