import javax.swing.*;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

public class RunnerClass implements ActionListener, KeyListener
{
	private static final int SCREEN_WIDTH = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	private static final int SCREEN_HEIGHT = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	private static final int PIPE_GAP = SCREEN_HEIGHT/5; //distance in pixels between pipes
	private static final int PIPE_WIDTH = SCREEN_WIDTH/8;
	private static final int PIPE_HEIGHT = 4*PIPE_WIDTH;
	private static final int BIRD_WIDTH = 120, BIRD_HEIGHT = 75;
	private static final int UPDATE_DIFFERENCE = 25; //time in ms between updates
	private static final int X_MOVEMENT_DIFFERENCE = 5; //distance the pipes move every update
	private static final int SCREEN_DELAY = 300; //needed because of long load times forcing pipes to pop up mid-screen
	private static final int BIRD_X_LOCATION = SCREEN_WIDTH/7;
	private static final int BIRD_JUMP_DIFF = 10; 
	private static final int BIRD_FALL_DIFF = BIRD_JUMP_DIFF/2; 
	private static final int BIRD_JUMP_HEIGHT = PIPE_GAP - BIRD_HEIGHT - BIRD_JUMP_DIFF*2;
	
	private JFrame f = new JFrame("Flappy Bird");
	private JButton startGame;
	private JPanel topPanel;
	
	private boolean runBackground = true; //false -> don't run loop; true -> run loop for pipes
	private boolean gamePlay = false; //false -> game not being played
	private boolean birdThrust = false; //false -> key has not been pressed to move the bird vertically
	private boolean birdJump = false; //true -> button pressed before jump completes
	private boolean spaceReleased = true; //space bar released; starts as true so first press registers
	private int birdYTracker = SCREEN_HEIGHT/2 - BIRD_HEIGHT;
	private Object completion = new Object();
	
	private static RunnerClass r = new RunnerClass();
	private static GameScreen pgs; //panel that has the moving background at the start of the game
	
	public static void main(String[] args) 
	{
		/**
		 * The thing about using a new thread was found online because the game was super laggy and freezing. From what I can tell,
		 * it allows the app to increase cpu usage and makes it less laggy. It is my code still, but I copied something else and reformed
		 * it to fit my purposes. I think originally it was for a space invaders game.
		 * @param args
		 */
		
		javax.swing.SwingUtilities.invokeLater(new Runnable() 
		{
			public void run() 
			{
				r.buildScreen();
				
				//create a new thread to keep the GUI responsive while the game runs
				Thread t = new Thread() {
					public void run() {
						r.gameScreen(true);
					}
				};
				t.start();
			}
		});
	}
	
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == startGame) 
		{
			runBackground = false;
			
			fade();
		}
		else if(e.getSource() == completion) 
		{
			Thread t = new Thread() 
			{
				public void run() 
				{
					runBackground = true;
					gamePlay = true;
					r.gameScreen(false);
				}
			};
			t.start();
		}
	}
	
	private JPanel createContentPane() {
		topPanel = new JPanel(); 
		topPanel.setBackground(Color.BLACK);
		LayoutManager overlay = new OverlayLayout(topPanel);
		topPanel.setLayout(overlay);
		
		startGame = new JButton("Start Game");
		startGame.setBackground(Color.BLUE);
		startGame.setForeground(Color.WHITE);
		startGame.setFocusable(false); 
		startGame.setFont(new Font("Sans Serif", Font.BOLD, 30));
		startGame.setAlignmentX(0.5f); 
		startGame.setAlignmentY(0.5f); 
		startGame.addActionListener(this);
		topPanel.add(startGame);
		pgs = new GameScreen(SCREEN_WIDTH, SCREEN_HEIGHT, true); 
		topPanel.add(pgs);
		
		return topPanel;
	}
		
		private void buildScreen() 
		{
			ImageIcon imageBird = new ImageIcon("resources/blue_bird.png");
			Image icon = imageBird.getImage();
			
			f.setContentPane(createContentPane());
	        f.setResizable(true);
	        f.addKeyListener(this);
	        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        f.setAlwaysOnTop(false);
	        f.setVisible(true);
	        Dimension dimension = new Dimension(SCREEN_WIDTH*1/4, SCREEN_HEIGHT*1/4);
	        f.setMinimumSize(dimension);
	        f.setExtendedState(JFrame.MAXIMIZED_BOTH);
	        f.setIconImage(icon);
		}
		
		public void keyPressed(KeyEvent e) 
		{
			if(e.getKeyCode() == KeyEvent.VK_SPACE && gamePlay == true && spaceReleased == true)
			{
				
				if(birdThrust) 
				{
					birdJump = true;
				}
				birdThrust = true;
				spaceReleased = false;
			}
			else if(e.getKeyCode() == KeyEvent.VK_B && gamePlay == false) 
			{
				birdYTracker = SCREEN_HEIGHT/2 - BIRD_HEIGHT; 
				birdThrust = false; 
				actionPerformed(new ActionEvent(startGame, -1, ""));
			}
		}
		
		private void fade() 
		{
			Thread t = new Thread() 
			{
				public void run() 
				{
					topPanel.remove(startGame);
					topPanel.remove(pgs);
					topPanel.revalidate();
					topPanel.repaint();
					
					//panel to fade
					int blackValue = 0;
					JPanel fader = new JPanel();
					fader.setBackground(new Color(0, 0, 0, blackValue)); //transparent, black JPanel
					topPanel.add(fader);
					topPanel.add(pgs);
					topPanel.revalidate();
					topPanel.repaint();
					
					long currentTime = System.currentTimeMillis();
					
					while(fader.getBackground().getAlpha() != 255) 
					{
						if((System.currentTimeMillis() - currentTime) > UPDATE_DIFFERENCE/2) 
						{
							if(blackValue < 245) 
							{
								blackValue = blackValue + 10;
							}
							else 
							{
								blackValue = 255;
							}
							
							fader.setBackground(new Color(0, 0, 0, blackValue));
						
							topPanel.revalidate();
							topPanel.repaint();
							currentTime = System.currentTimeMillis();
						}
					}
					
					topPanel.removeAll();
					topPanel.add(fader);
					pgs = new GameScreen(SCREEN_WIDTH, SCREEN_HEIGHT, false);
					pgs.sendText(""); //remove title text
					topPanel.add(pgs);
					
					while(fader.getBackground().getAlpha() != 0) {
						if((System.currentTimeMillis() - currentTime) > UPDATE_DIFFERENCE/2) 
						{
							if(blackValue > 10) 
							{
								blackValue -= 10;
							}
							else 
							{
								blackValue = 0;
							}
							
							fader.setBackground(new Color(0, 0, 0, blackValue));
						
							topPanel.revalidate();
							topPanel.repaint();
							currentTime = System.currentTimeMillis();
						}
					}
					
					actionPerformed(new ActionEvent(completion, -1, "Build Finished"));
				}
			};
			
			t.start();
		}
		
		private int bottomPipeLoc() {
			int temp = 0;
			while(temp <= PIPE_GAP+50 || temp >= SCREEN_HEIGHT-PIPE_GAP) 
			{
				temp = (int) ((double) Math.random()*((double)SCREEN_HEIGHT));
			}
			return temp;
		}
		
		private void updateScore(BottomPipe bp1, BottomPipe bp2, Bird bird) {
			if(bp1.getX() + PIPE_WIDTH < bird.getX() && bp1.getX() + PIPE_WIDTH > bird.getX() - X_MOVEMENT_DIFFERENCE) {
				pgs.incrementJump();
			}
			else if(bp2.getX() + PIPE_WIDTH < bird.getX() && bp2.getX() + PIPE_WIDTH > bird.getX() - X_MOVEMENT_DIFFERENCE) {
				pgs.incrementJump();
			}
		}
		
		private void gameScreen(boolean isSplash) 
		{
			BottomPipe bp1 = new BottomPipe(PIPE_WIDTH, PIPE_HEIGHT);
			BottomPipe bp2 = new BottomPipe(PIPE_WIDTH, PIPE_HEIGHT);
			TopPipe tp1 = new TopPipe(PIPE_WIDTH, PIPE_HEIGHT);
			TopPipe tp2 = new TopPipe(PIPE_WIDTH, PIPE_HEIGHT);
			Bird bird = new Bird(BIRD_WIDTH, BIRD_HEIGHT);
			
			//variables to track x and y image locations for the bottom pipe
			int xLoc1 = SCREEN_WIDTH+SCREEN_DELAY;
			int xLoc2 = (int) ((double) 3.0/2.0*SCREEN_WIDTH+PIPE_WIDTH/2.0)+SCREEN_DELAY;
			int yLoc1 = bottomPipeLoc();
			int yLoc2 = bottomPipeLoc();
			int birdX = BIRD_X_LOCATION, birdY = birdYTracker;
			
			//variable to hold the loop start time
			long startTime = System.currentTimeMillis();
			
			while(runBackground) {
				if((System.currentTimeMillis() - startTime) > UPDATE_DIFFERENCE) {
					//check if a set of pipes has left the screen
					//and set new ones
					if(xLoc1 < (0-PIPE_WIDTH)) {
						xLoc1 = SCREEN_WIDTH;
						yLoc1 = bottomPipeLoc();
					}
					else if(xLoc2 < (0-PIPE_WIDTH)) {
						xLoc2 = SCREEN_WIDTH;
						yLoc2 = bottomPipeLoc();
					}
					
					//increment the pipe locations
					xLoc1 -= X_MOVEMENT_DIFFERENCE;
					xLoc2 -= X_MOVEMENT_DIFFERENCE;
					
					if(birdJump && !isSplash) {
						birdYTracker = birdY;
						birdJump = false;
					}
					
					if(birdThrust && !isSplash) 
					{
						//move bird vertically
						if(birdYTracker - birdY - BIRD_JUMP_DIFF < BIRD_JUMP_HEIGHT) 
						{
							if(birdY - BIRD_JUMP_DIFF > 0) 
							{
								birdY -= BIRD_JUMP_DIFF;
							}
							else 
							{
								birdY = 0;
								birdYTracker = birdY;
								birdThrust = false;
							}
						}
						else 
						{
							birdYTracker = birdY;
							birdThrust = false;
						}
					}
					else if(!isSplash) 
					{
						birdY += BIRD_FALL_DIFF;
						birdYTracker = birdY;
					}
					
					//update the BottomPipe and TopPipe locations
					bp1.setX(xLoc1);
					bp1.setY(yLoc1);
					bp2.setX(xLoc2);
					bp2.setY(yLoc2);
					tp1.setX(xLoc1);
					tp1.setY(yLoc1-PIPE_GAP-PIPE_HEIGHT); 
					tp2.setX(xLoc2);
					tp2.setY(yLoc2-PIPE_GAP-PIPE_HEIGHT); 
					
					if(!isSplash) 
					{
						bird.setX(birdX);
						bird.setY(birdY);
						pgs.setBird(bird);
					}
					
					pgs.setBottomPipe(bp1, bp2);
					pgs.setTopPipe(tp1, tp2);
					
					if(!isSplash && bird.getWidth() != -1) 
					{ 
						collisionDetection(bp1, bp2, tp1, tp2, bird);
						updateScore(bp1, bp2, bird);
					}
					
					topPanel.revalidate();
					topPanel.repaint();
					
					startTime = System.currentTimeMillis();
				}
			}
		}
		
		private void collisionDetection(BottomPipe bp1, BottomPipe bp2, TopPipe tp1, TopPipe tp2, Bird bird) 
		{
			if(bird.getY() + BIRD_HEIGHT > SCREEN_HEIGHT*7/8) 
			{
				pgs.sendText("Game Over");
				runBackground = false;
				gamePlay = false; //game has ended
			}
			
			collisionHelper(bird.getRectangle(), bp1.getRectangle(), bird.getBI(), bp1.getBI());
			collisionHelper(bird.getRectangle(), bp2.getRectangle(), bird.getBI(), bp2.getBI());
			collisionHelper(bird.getRectangle(), tp1.getRectangle(), bird.getBI(), tp1.getBI());
			collisionHelper(bird.getRectangle(), tp2.getRectangle(), bird.getBI(), tp2.getBI());
		}
		
		private void collisionHelper(Rectangle r1, Rectangle r2, BufferedImage b1, BufferedImage b2) 
		{
			if(r1.intersects(r2)) 
			{
				Rectangle r = r1.intersection(r2);
				
				int pixelX = (int) (r.getMinX() - r1.getMinX());
				int pixelY = (int) (r.getMinY() - r1.getMinY());
				int bp1X = (int) (r1.getMinX() - r2.getMinX());
				int bp1Y = (int) (r1.getMinY() - r2.getMinY());
				
				for(int i = pixelX; i < r.getWidth() + pixelY; i++) 
				{
					for(int j = pixelX; j < r.getHeight() + pixelY; j++) 
					{
						if((b1.getRGB(i, j) & 0xFF000000) != 0x00 && (b2.getRGB(i + bp1X, j + bp1Y) & 0xFF000000) != 0x00) 
						{
							pgs.sendText("Game Over");
							runBackground = false; //stop background
							gamePlay = false; //game has ended
							break;
						}
					}
				}
			}
		}

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}

