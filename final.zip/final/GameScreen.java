import javax.swing.*;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Color;

public class GameScreen extends JPanel 
{
	private int screenWidth;
	private int screenHeight;
	private BottomPipe bp1;
	private BottomPipe bp2;
	private TopPipe tp1;
	private TopPipe tp2;
	private Bird bird;
	private boolean isSplash = true;
	private int completedJumps = 0;
	private String message = "Flappy Bird";
	private Font font = new Font("Sans Serif", Font.BOLD, 50);
	private int messageWidth = 0;
	private int scoreWidth = 0;
	
	public GameScreen(int screenWidth, int screenHeight, boolean isSplash) 
	{
		this.screenWidth = screenWidth;
		this.screenHeight = screenHeight;
		this.isSplash = isSplash;
	}
	
	public void setBottomPipe(BottomPipe bp1, BottomPipe bp2) 
	{
		this.bp1 = bp1;
		this.bp2 = bp2;
	}
	
	public void setTopPipe(TopPipe tp1, TopPipe tp2) 
	{
		this.tp1 = tp1;
		this.tp2 = tp2;
	}
	
	public void setBird(Bird bird) 
	{
		this.bird = bird;
	}
	
	public int getScore() 
	{
		return completedJumps;
	}
	
	public void incrementJump() 
	{
		completedJumps++;
	}
	
	public void sendText(String message) 
	{
		this.message = message;
	}
	
	public void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		
		g.setColor(new Color(0, 91, 255)); //Color for sky
		g.fillRect(0, 0, screenWidth, screenHeight*7/8); //Makes the sky background
		g.setColor(new Color(34, 139, 34)); //Creates the ground color
		g.fillRect(0, screenHeight*7/8, screenWidth, screenHeight/8); //create the ground base
		g.setColor(Color.BLACK); //Draws divider between the two
		g.drawLine(0, screenHeight*7/8, screenWidth, screenHeight*7/8);
		
		if(bp1 != null && bp2 != null && tp1 != null && tp2 != null) 
		{
			g.drawImage(bp1.getBottomPipe(), bp1.getX(), bp1.getY(), null);
			g.drawImage(bp2.getBottomPipe(), bp2.getX(), bp2.getY(), null);
			g.drawImage(tp1.getTopPipe(), tp1.getX(), tp1.getY(), null);
			g.drawImage(tp2.getTopPipe(), tp2.getX(), tp2.getY(), null);
		}
		
		if(!isSplash && bird != null) 
		{
			g.drawImage(bird.getBird(), bird.getX(), bird.getY(), null);
		}
		
		if(!isSplash) 
		{
			g.drawString(String.format("%d", completedJumps), screenWidth/2-scoreWidth/2, 50);
		}
		
			g.setFont(font);
			FontMetrics metric = g.getFontMetrics(font);
			messageWidth = metric.stringWidth(message);
			scoreWidth = metric.stringWidth(String.format("%d", completedJumps));
		
		g.drawString(message, screenWidth/2-messageWidth/2, screenHeight/4);
		
	}
}
